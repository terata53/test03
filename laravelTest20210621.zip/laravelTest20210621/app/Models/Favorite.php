<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use phpDocumentor\Reflection\Types\Boolean;

class Favorite extends Model
{
    public $timestamps = false;

    // いいねしているかどうかの判定処理
    public function isFavorite(Int $user_id, Int $message_id)
    {
        return (boolean) $this->where('user_id', $user_id)->where('message_id', $message_id)->first();
    }

    public function storeFavorite(Int $user_id, Int $message_id)
    {
        $this->user_id = $user_id;
        $this->message_id = $message_id;
        $this->save();

        return;
    }

    public function deatroyFavorite(Int $favorite_id)
    {
        return $this->where('id', $favorite_id)->delete();
    }
}
