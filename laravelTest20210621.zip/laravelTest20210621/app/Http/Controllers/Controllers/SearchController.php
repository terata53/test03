<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Message;

class SearchController extends Controller
{
    public function index(Request $request, Message $message){
        $user = auth()->user();
        $keyword = $request->input('keyword');

        if(!empty($keyword)){
            $messages_data = $message->messageSearch($keyword);
            return view('search.index', [
                'user' => $user,
                'messages_data' => $messages_data,
                'keyword' => $keyword
            ]);
        }

        return view('search.index', [
            'user' => $user,
            'messages_data' => [],
            'keyword' => '検索ワード'
        ]);
    }
}
